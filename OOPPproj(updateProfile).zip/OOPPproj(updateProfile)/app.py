from flask import Flask, render_template, request
from persistence import *

app = Flask(__name__)


@app.route('/')
def index():
    return ('homePage')  # nothing there



@app.route("/profile")
def profile():
    return render_template('profile.html')




@app.route('/update', methods=['POST', 'GET'])
def update():
    if request.method == 'POST':
        username = request.form['username']
        name = request.form['fullname']
        nric = request.form['nric']
        email = request.form['email']
        password = request.form['newpass']
        role = request.form['role']

        user = User()
        user.id = username
        user.name = name
        user.nric = nric
        user.email = email
        user.password = password
        user.role = role

        # store user object in persistence
        create_user(user)
        return render_template('success.html')



if __name__ == "__main__":
    app.run(debug=True)
