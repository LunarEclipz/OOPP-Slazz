import shelve

class User:
    def __init__(self):
        self.id = ''
        self.name = ''
        self.email = ''
        self.password = ''
        self.ezlink = ''
        self.nric = ''
        self.role = ''

users = shelve.open('users')

def create_user(user):
    users[user.id] = user
    users[user.password] = user