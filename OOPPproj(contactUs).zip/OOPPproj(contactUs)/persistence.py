import shelve


class User:
    def __init__(self):
        self.id = ''
        self.email = ''
        self.message = ''


users = shelve.open('users')

def create_contactUs(contactUs, id, email, message):
    users[contactUs.id] = contactUs
    users[contactUs.email] = contactUs
    users[contactUs.message] = contactUs

#contactUs,