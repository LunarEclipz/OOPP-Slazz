from flask import Flask, render_template, request
from persistence import *

app = Flask(__name__)


@app.route('/')
def index():
    return 'homePage'



@app.route('/userSetting')
def userSetting():
    return render_template('userSetting.html')




@app.route('/userSetting/profile')
def profile():
    return render_template('profile.html')


@app.route('/userSetting/contactUs', methods=["GET", "POST"])
def contactUs():
    if request.method == 'POST':
        id = request.form.get('id')
        email = request.form.get('email')
        message = request.form.get('message')

        contactUs = User()
        contactUs.id = id
        contactUs.email = email
        contactUs.message = message

        create_contactUs(contactUs, id, email, message)
        return render_template('contactUs.html')
    else:
        return render_template('contactUs.html')


if __name__ == "__main__":
    app.run(debug=True)