from flask import *
from user import *
from forms import *
from functools import wraps
from message import *
from persistence import *


app = Flask(__name__)
app.config.from_mapping(
    SECRET_KEY='dev'
)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/about')
def about():
    return render_template('about.html')

#User Login
@app.route('/login',  methods=('GET', 'POST'))
def login():
    login_form = LoginForm(request.form)
    if request.method == 'POST':
        user = get_user(login_form.id.data, login_form.password.data)
        if user is None:
            error = 'Incorrect username and/or password'
        else:
            session['logged_in'] = True
            session['username'] = user.id

            flash('You are now logged in','success')
            return redirect(url_for('profile'))

        flash(error)
    return render_template('login.html', form=login_form)

#Register Account
@app.route('/register', methods=('GET', 'POST'))
def register():
    form = RegisterForm(request.form)
    if request.method == 'POST' and form.validate():
        id = form.id.data
        email = form.email.data
        password = form.password.data
        create_user(id, email, password)
        flash('You are now registered and can log in.', 'success')
        return redirect(url_for('login'))
    return render_template('register.html', form=form)

#Check if user is logged in
def is_logged_in(f):
    @wraps(f)
    def wrap(*args, **kwargs):
        if 'logged_in' in session:
            return f(*args, **kwargs)
        else:
            flash('Unauthorized, Please login', 'danger')
            return redirect(url_for('login'))
    return wrap

#Logout
@app.route('/logout', methods=('GET', 'POST'))
def logout():
    session.clear()
    return redirect(url_for('login'))



#user settings part(Lousia's Part)
@app.route("/profile")
def profile():
    name = session['username']
    user = retrieve_user(name)
    return render_template('profile.html', user = user)


@app.route('/update', methods=['POST', 'GET'])
def update():
    if request.method == 'POST':
        username = request.form['username']
        name = request.form['fullname']
        nric = request.form['nric']
        email = request.form['email']
        password = request.form['newpass']

        user = User()
        user.id = username
        user.name = name
        user.nric = nric
        user.email = email
        user.password = password

        # store user object in persistence
        update_user(user)
        return render_template('success.html')


@app.route('/balance')
def balance():
    return render_template('balance.html')


@app.route('/message', methods=['GET'])
def message():
    name = session['username']
    messages = get_message(name)
    return render_template('message.html', messages = messages)


@app.route('/contactUs', methods=["GET", "POST"])
def contactUs():
    if request.method == 'POST':
        id = request.form.get('id')
        email = request.form.get('email')
        message = request.form.get('message')

        contactUs = feedbackUser()
        contactUs.id = id
        contactUs.email = email
        contactUs.message = message

        create_contactUs(contactUs, id, email, message)
        return render_template('contactUs.html')
    else:
        return render_template('contactUs.html')


@app.route('/testmessage', methods=["GET", "POST"])
def test_message():
    send_transferred_message('louisa', 500)
    send_transferred_message('louisa', 100)
    return 'created test messages to louisa'



if __name__ == '__main__':
    app.run(debug=True)

