import shelve

bookstore = shelve.open('books.db')
books_length = len(bookstore)
print(books_length)

