from flask import Flask, render_template
from Library import Book, Due_date, Reminder


app = Flask(__name__)


@app.route('/')
def libraryhome():
    return render_template("Library.html")


@app.route('/Reminders')
def reminders():
    bk = ['Dante', 'Locker B']
    books = Book.Book
    reminder = Reminder.Reminder
    return render_template("Reminders.html", books=books, reminder=reminder, bk=bk)


@app.route('/Payment')
def payment():
    return render_template("Payment.html")


@app.route('/RecommendedBooks')
def recBooks():
    return render_template("RecommendedBooks.html")


@app.route('/BooksOnLoan')
def loaned():
    book = Book
    duedate = Due_date
    return render_template('BorrowedBooks.html', book=book, duedate=duedate)


if __name__ == '__main__':
    app.run(debug=True)
