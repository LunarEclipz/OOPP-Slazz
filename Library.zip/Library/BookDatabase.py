import shelve


def store(title, book):
    bookstore = shelve.open('books.db')
    bookstore[title] = book

